use adventureworks;

select file_id, name, physical_name, size from sys.database_files;