use adventureworks

select 'Index Name' = i.[name],
       'Stats Date' = stats_date(i.[object_id], i.index_id)
 from sys.objects o
  inner join sys.indexes i
   on o.name = 'Employee'
   and
    o.[object_id] = i.[object_id];

